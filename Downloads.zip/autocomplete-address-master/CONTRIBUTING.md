# Contributing

1. Fork it!
2. Create your feature branch: `git checkout -b my-new-feature`
3. Commit your changes: `git commit -m 'Add some feature'`
4. Push to the branch: `git push origin my-new-feature`
5. Submit a pull request :D

Don't edit files under `dist` folder, those are generated after running `grunt` command, edit files under `src` folder instead.

Also remember to follow [jQuery's Code Style](http://contribute.jquery.org/style-guide/js/).